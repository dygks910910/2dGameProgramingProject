﻿from pico2d import *

class Tower:
    img = None
    FIRE,STOP = 1,2
    def __init__(self,x,y):
        if(Tower.img == None):
            self.img = load_image("Texture\\BaseTowerSprite.png")
        self.x = x
        self.y = y
        self.frame = 0  #총19개 이미지
        self.imgX = 0
        self.imgY = 50
        self.option = self.FIRE
        self.att = 25
        self.fire = False
    def update(self):
        self.frame = (self.frame +1 )%19
    def draw(self):
        if self.option == self.FIRE:
            self.img.clip_draw((self.imgX+50)*self.frame,self.imgY-50,50,50,self.x,self.y)
        else:
            self.img.clip_draw((self.imgX+50)*self.frame,self.imgY,50,50,self.x,self.y)
        