﻿import random
import json
import os

from pico2d import *
import MainStateLV1
import game_framework
import title_state
import Tower


name = "MainState"
mainImg = None
font = None
tower = None
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
colorLv1 = RED
colorLv2 = RED
colorLv3 = RED
colorExit = RED

lv1x =270
lv1y = 200

lv2x = 270
lv2y = 140

lv3x = 270
lv3y = 80 
 
exitx = 270
exity = 20
def enter():
    global mainImg,font
    mainImg = load_image("Texture\\TitleImg.png")
    font = load_font("font.ttf",60)
    pass


def exit():
    pass


def pause():
    pass


def resume():
    pass


def handle_events():
    global lv1x,lv1y,lv2x,lv2y,lv3x,lv3y,colorLv1,colorLv2,colorLv3,colorExit
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_MOUSEMOTION:
            if (lv1x < event.x and lv1x + 100 > event.x and lv1y -30 < 600-event.y and lv1y +30 > 600-event.y):
                colorLv1 = BLUE
            else:
                colorLv1 = RED  
            if (lv2x < event.x and lv2x + 100 > event.x and lv2y -30 < 600-event.y and lv2y +30 > 600-event.y):
                colorLv2 = BLUE
            else:
                colorLv2 = RED  
            if (lv3x < event.x and lv3x + 100 > event.x and lv3y -30 < 600-event.y and lv3y +30 > 600-event.y):
                colorLv3 = BLUE
            else:
                colorLv3 = RED     
            if (exitx < event.x and exitx+ 100 > event.x and exity-30 < 600-event.y and exity+30 > 600-event.y):
                colorExit = BLUE
            else:
                colorExit = RED     
        elif event.type == SDL_MOUSEBUTTONDOWN and event.button == SDL_BUTTON_LEFT:
            if (lv1x < event.x and lv1x + 100 > event.x and lv1y -30 < 600-event.y and lv1y +30 > 600-event.y):
                 game_framework.change_state(MainStateLV1)
            #elif (lv2x < event.x and lv2x + 100 > event.x and lv2y -30 < 600-event.y and lv2y +30 > 600-event.y):
            #    game_framework.change_state(MainStateLV2)
            #elif (lv3x < event.x and lv3x + 100 > event.x and lv3y -30 < 600-event.y and lv3y +30 > 600-event.y):
            #    game_framework.change_state(MainStateLV3)
            elif (exitx < event.x and exitx+ 100 > event.x and exity-30 < 600-event.y and exity+30 > 600-event.y):
                game_framework.quit()
def update():
    pass


def draw():
    clear_canvas()
    mainImg.draw(400,300)
    font.draw(lv1x,lv1y,"LV1 ",colorLv1)
    font.draw(lv2x,lv2y,"LV2 ",colorLv2)
    font.draw(lv3x,lv3y,"LV3 ",colorLv3)
    font.draw(exitx,exity,"EXIT",colorExit)
    update_canvas()
    
def test_this():
    open_canvas()
    pass

if __name__ == "__main__":
     test_this()



