﻿from pico2d import *
import math
tower = None
class Tower:
    index = []
    img = None
    FIRE,STOP = 1,2
    price = 100
    def __init__(self,x,y):
        if(len(Tower.index) == 0):
            for i in range(0,20):
                self.index.append(18*i)
                print("%d"%(18*i))
        if(Tower.img == None):
            self.img = load_image("Texture\\BaseTowerSprite.png")
        self.x = x
        self.y = y
        self.frame = 0  #총19개 이미지
        self.imgX = 0
        self.imgY = 50
        self.range = 150 #반경50

        self.option = self.FIRE
        self.att = 50
        self.fire = False
        self.towerLv = 1
        self.towerPrice = 100
    def update(self,monsterX,monsterY):
        if(self.culcuratingRange(monsterX,monsterY)):
            frame = self.calcuratorToDegree(monsterX,monsterY)
            self.frame = frame
        pass
    def draw(self):
        if self.option == self.FIRE:
             self.img.clip_draw((self.imgX+50)*self.frame,self.imgY-50,50,50,self.x,self.y)
        else:
            self.img.clip_draw((self.imgX+50)*self.frame,self.imgY,50,50,self.x,self.y)
    def culcuratingRange(self,monsterX,monsterY):
        if(self.x >= monsterX):
           if(math.sqrt(((self.x-monsterX)*(self.x-monsterX)+((self.y - monsterY)*(self.y-monsterY)))) <= self.range):
               return True
           else:
               return False
        elif(self.x <= monsterX):
            if(math.sqrt((monsterX-self.x)*(monsterX-self.x)+(monsterY-self.y)*(monsterY-self.y)) <= self.range):
                return True
            else:
                return False

    def calcuratorToDegree(self,monsterX,monsterY):
         print("거리:%d"%(math.sqrt(((self.x-monsterX)*(self.x-monsterX)+((self.y - monsterY)*(self.y-monsterY))))))
         x = monsterX- self.x
         y= monsterY-self.y
         temp = math.atan2(y,x)#y/x 계산해줌
         
         degree = temp*(180/3.14159265)
         if(degree < 0):
            degree = 359+degree
            print("%d"%(degree))
         for i in range(0,20):
              if i == 19:
                    if(self.index[19] <= degree and degree >= self.index[0]):
                         return 19
              elif(self.index[i] <= degree and degree <= self.index[i+1]):
                    return i
         else:
            return 0
    def attack(anermy):
        pass
def testing_debug():
   
    
    open_canvas()
    global tower
    tower = Tower(400,300)
    while(True):
       clear_canvas()
       handle_events()
       tower.draw()
       update_canvas()


def handle_events():
    events = get_events()

    global tower
    for event in events:
        if event.type == SDL_MOUSEMOTION:
            tower.update(event.x,600-event.y)
if __name__ == "__main__":
    testing_debug()