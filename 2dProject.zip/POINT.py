﻿from pico2d import *

class POINT:
    img = None
    OBJECT_TYPE_1,OBJECT_TYPE_2,OBJECT_TYPE_3,OBJECT_TYPE_4,OBJECT_TYPE_5 = 1,2,3,4,5
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.state = True #오브젝트가 존재하면 False
        self.type = None
        if POINT.img == None:
            self.img = load_image("Texture\\Tile.png")
    def GetXY(self,XorYorState):
        if(XorYorState == 'x'):
            return self.x
        elif(XorYorState == 'y'):
            return self.y
        elif (XorYorState == 'state'):
            return self.state
    def drawTemp(self):
        self.img.draw(self.x,self.y)
        



