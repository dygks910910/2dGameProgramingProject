﻿import enemyType1
from pico2d import *
class enermyType2(enemyType1.enemyType1):
    Img = None
    def __init__(self,tile):
        if self.Img == None:
            self.Img = load_image("Texture\\enermyLV2.png")
        if self.TILE_LIST == None:
            self.TILE_LIST = tile
        self.frame= 0
        self.speed = 0.5
        self.hp = 100
        self.x = self.START_POINT_X
        self.y = self.START_POINT_Y
        self.state = self.RIGHT
    def update(self):
        self.frame = (self.frame+1) %8
        self.changeState()
        self.handle_state[self.state](self)
    def draw(self):
        self.Img.clip_draw(40*self.frame,0,40,40,self.x,self.y)
    """description of class"""


