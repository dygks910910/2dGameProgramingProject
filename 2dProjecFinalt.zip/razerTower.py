from pico2d import *
import Tower
import bullet
class razerTower(Tower.Tower):
    priceLV1 = 250
    img = None
    def __init__(self,x,y):
        if(len(razerTower.index) == 0):
            for i in range(0,20):
                self.index.append(18*i)
                print("%d"%(18*i))
        if(razerTower.img == None):
            self.img = load_image("Texture\\RazerTower.png")
        self.bullet = bullet.bullet(x,y) 
        self.bullet.dmg = 10
        self.frame= 0
        self.option = self.STOP
        self.x = x  
        self.y = y
        self.frame = 0  #총19개 이미지
        self.imgX = 0
        self.imgY = 50
        self.range = 300
    def draw(self):
        if self.option == self.FIRE:
            self.img.clip_draw((self.imgX+50)*self.frame,self.imgY,50,50,self.x,self.y)
            self.bullet.draw()
        else:
            self.img.clip_draw((self.imgX+50)*self.frame,self.imgY,50,50,self.x,self.y)
    
    def update(self,enermy):
        if(self.culcuratingRange(enermy.x,enermy.y)):
            frame = self.calcuratorToDegree(enermy.x,enermy.y)
            self.frame = frame
        if(self.option == self.FIRE):
            if self.bullet.deleteState == True:
                del(self.bullet)
                self.bullet = bullet.bullet(self.x,self.y)
            self.bullet.update(enermy)
        pass

    """description of class"""



    pass






