﻿from pico2d import *
import POINT
import GameManager

class enemyType1:
    START_POINT_X = 25
    START_POINT_Y = 275
    Img = None
    LEFT,RIGHT,UP,DOWN = 1,2,3,4
    TILE_LIST = None
    hp_gage_img = None
    def __init__(self,tile):
        if(enemyType1.TILE_LIST == None):
            self.TILE_LIST =tile
        if(enemyType1.Img == None):
            self.Img = load_image("Texture\\enermyLV1.png")
        if(enemyType1.hp_gage_img == None):
            self.hp_gage_img = load_image("Texture\\hp_gage_img.png")
        self.frame= 0
        self.speed = 1
        self.hp = 50
        self.x = self.START_POINT_X
        self.y = self.START_POINT_Y
        self.state = self.RIGHT
        self.delSwitch = False
        self.money = 200
        self.aliveEnermy = False
    def left_move(self):
        self.x -= self.speed
    def right_move(self):
        self.x += self.speed
    def up_move(self):
        self.y += self.speed
    def down_move(self):
        self.y -= self.speed


    def changeState(self):
        for i in range(0,12):
            for j in range(0,16):
               if (self.TILE_LIST[i][j].x  == self.x and self.TILE_LIST[i][j].y==self.y):
                   if(j+1 <= 15 and self.TILE_LIST[i][j+1].state == True ):
                       self.state = self.RIGHT
                   elif(i+1 <= 11 and self.TILE_LIST[i+1][j].state == True):
                        self.state = self.UP
                   elif(j-1 >= 0 and self.TILE_LIST[i][j-1].state == True):
                        self.state = self.LEFT
                   elif( i-1 >= 0 and self.TILE_LIST[i-1][j].state == True):
                        self.state = self.DOWN
                   if(i<5 and self.TILE_LIST[i][15].x == self.x):
                       self.state = self.UP
                   if(i>5 and self.TILE_LIST[i][15].x == self.x):
                       self.state = self.DOWN
        if(self.TILE_LIST[5][15].x-25 < self.x and self.TILE_LIST[5][15].x+25 > self.x and self.TILE_LIST[5][15].y-25 < self.y and self.TILE_LIST[5][15].y+25 > self.y):
                       self.state = self.RIGHT
                   
                   
                        
        ######

        #for i in range(0,12):
        #    for j in range(0,16):
        #       if (self.TILE_LIST[i][j].GetXY('x')  == self.x and self.TILE_LIST[i][j].GetXY('y') ==self.y ):
        #           if(self.state == self.RIGHT):
        #               if(j < 14 and self.TILE_LIST[i][j+1].state == False):
        #                   self.state = self.UP
        #               if(j < 14 and self.TILE_LIST[i][j+1].state == False and self.TILE_LIST[i+1][j] == False):
        #                   self.state = self.DOWN
        #                ###---------------------------------------------------------------------------
        #               if(j == 15 and i < 5):
        #                   self.state = self.UP
        #               elif(j == 15 and i > 5):
        #                   self.state = self.DOWN
        #           elif(self.state == self.UP):
        #               if(i == 11 or(i < 11 and self.TILE_LIST[i+1][j].state == False )):
        #                   self.state = self.RIGHT
        #           elif(self.state == self.DOWN):
        #               if(i > 0 and self.TILE_LIST[i-1][j].state == False):
        #                   self.state = self.RIGHT
        #           elif(self.state == self.LEFT):
        #               if(j > 0 and self.TILE_LIST[i][j-1].state == False):
        #                   self.state = self.DOWN
        #           if(j == 15 and i == 5):
        #               self.state = self.RIGHT
                  
        #           break
        #if(self.state == self.UP):
        #           print("state: up")
        #if(self.state == self.DOWN):
        #           print("state: down")
        #if(self.state == self.LEFT):
        #           print("state: left")
        #if(self.state == self.RIGHT):
        #           print("state: right")
                   


    handle_state ={
        LEFT:left_move,
        RIGHT:right_move,
        UP:up_move,
        DOWN:down_move
       }
         
    def update(self):
        self.frame = (self.frame+1)%4
        self.changeState()
        self.handle_state[self.state](self)
        if(self.hp <= 0):
            self.delSwitch = True
        if(self.x > 825):
            self.aliveEnermy = True

    def draw(self):
        self.Img.clip_draw(30*self.frame,0,30,30,self.x,self.y)
        self.hp_gage_img.clip_draw(0,0,int(self.hp/2),5,self.x,self.y+25)


