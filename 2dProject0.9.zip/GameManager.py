﻿from pico2d import *
import POINT
import Tower
import Tower2
import enemyType1
import enermyType2


name = "lv1"

class GameManager:
    BASE_TOWER_TYPE,BASE_TOWER_TYPE2,BASE_TOWER_TYPE3,BASE_TOWER_TYPE4,BASE_TOWER_TYPE5 = 1,2,3,4,5
    IMG_HALF_WIDTH = 25
    START,STOP ,fast2x = 1,2,3
    TYPE = None
    TILE = []
    tower_list = []
    tower1Img = None
    tower2Img = None
    tower3Img = None
    tower4Img = None
    tower5Img = None
    settingImg = None
    fast2xImg = None
    moneyImg = None
    puseImg = None
    startImg = None
    lifeImg = None
    drag = None
    def __init__(self):
        self.tower1ImgX = 400
        self.tower1ImgY = 550
        self.font = load_font("font.ttf",20)
        self.scoreFont = load_font("font.ttf",40)
        
           
        self.tower2ImgX = 450
        self.tower2ImgY = 550

        self.tower3ImgX = 500
        self.tower3ImgY = 550

        self.tower4ImgX = 550
        self.tower4ImgY = 550

        self.tower5ImgX = 600
        self.tower5ImgY = 550

        self.fast2xImgX = 50
        self.fast2xImgY = 550
        
        self.puseImgX = 150
        self.puseImgY = 550

        self.startImgX = 100
        self.startImgY = 550

        self.settingImgX = 750
        self.settingImgY = 550

        self.lifeImgX = 700
        self.lifeImgY = 30

        self.moneyImgX = 50
        self.moneyImgY = 580

        self.round = 0
        self.Playerlife = 20
        self.drag = False
        self.scoreX = 380
        self.scoreY = 580
        self.time = 0
        self.watingTime = 30
        self.option = self.STOP
        self.Playermoney = 0
        self.Playerscore = 0
        self.enemyLV = 0
        self.countEnermy = 0
        self.forCount = 0
        self.enemy = []
        for y in range(0,12):
            self.TILE.append([])
            for x in range(0,16):
                #self.TILE.append(POINT.POINT((x*(self.IMG_HALF_WIDTH*2))+(self.IMG_HALF_WIDTH),(y*(self.IMG_HALF_WIDTH*2))+(self.IMG_HALF_WIDTH)))
                self.TILE[y].append(POINT.POINT((x * (self.IMG_HALF_WIDTH * 2)) + (self.IMG_HALF_WIDTH),(y * (self.IMG_HALF_WIDTH * 2)) + (self.IMG_HALF_WIDTH)))
        if(GameManager.tower1Img == None):
            self.tower1Img = load_image("Texture\\BaseTowerImg.png")
        if(GameManager.tower2Img == None):
            self.tower2Img = load_image("Texture\\Base2TowerImg.png")
        if(GameManager.fast2xImg == None):
            self.fast2xImg = load_image("Texture\\Fast2XImg.png")
        if(GameManager.startImg == None):
            self.startImg = load_image("Texture\\StartImg.png")
        if(GameManager.puseImg == None):
            self.puseImg = load_image("Texture\\PuseImg.png")
        if(GameManager.moneyImg == None):
            self.moneyImg = load_image("Texture\\MoneyImg.png")
        if(GameManager.tower3Img == None):
            self.tower3Img = load_image("Texture\\Tower3Img.png")
        if(GameManager.tower3Img == None):
            self.tower4Img = load_image("Texture\\Tower4Img.png")
        if(GameManager.tower3Img == None):
            self.tower5Img = load_image("Texture\\Tower5Img.png")
        if(GameManager.settingImg == None):
            self.settingImg = load_image("Texture\\SettingImg.png")
        if(GameManager.lifeImg == None):
            self.lifeImg = load_image("Texture\\lifeImg.png")
    def mouseFunc(self,eventtype,x,y,eventbutton):
        if(eventbutton == SDL_BUTTON_RIGHT):
            self.drag = False
            self.TYPE = None

        if(eventtype == SDL_MOUSEBUTTONDOWN and eventbutton == SDL_BUTTON_LEFT):
            if(self.fast2xImgX - self.IMG_HALF_WIDTH < x and self.fast2xImgY - self.IMG_HALF_WIDTH < y and self.fast2xImgX + self.IMG_HALF_WIDTH > x and self.fast2xImgY + self.IMG_HALF_WIDTH > y):
                print("fast2xImgXtrue")

            elif(self.startImgX - self.IMG_HALF_WIDTH < x and self.startImgY - self.IMG_HALF_WIDTH < y and self.startImgX + self.IMG_HALF_WIDTH > x and self.startImgY + self.IMG_HALF_WIDTH > y):
                print("startImgXtrue")
                self.option = self.START
            
            elif(self.tower1ImgX - self.IMG_HALF_WIDTH < x and self.tower1ImgY - self.IMG_HALF_WIDTH < y and self.tower1ImgX + self.IMG_HALF_WIDTH > x and self.tower1ImgY + self.IMG_HALF_WIDTH > y):
                self.drag = True
                self.TYPE = self.BASE_TOWER_TYPE
                print("startImgXtrue")

            elif(self.tower2ImgX - self.IMG_HALF_WIDTH < x and self.tower2ImgY - self.IMG_HALF_WIDTH < y and self.tower2ImgX + self.IMG_HALF_WIDTH > x and self.tower2ImgY + self.IMG_HALF_WIDTH > y):
                self.drag = True
                self.TYPE = self.BASE_TOWER_TYPE2
                print('BASE_TOWER_TYPE2')
            elif(self.puseImgX - self.IMG_HALF_WIDTH < x and self.puseImgY - self.IMG_HALF_WIDTH < y and self.puseImgX + self.IMG_HALF_WIDTH > x and self.puseImgY + self.IMG_HALF_WIDTH > y):
                self.option = self.STOP
            elif(self.tower3ImgX - self.IMG_HALF_WIDTH < x and self.tower3ImgY - self.IMG_HALF_WIDTH < y and self.tower3ImgX + self.IMG_HALF_WIDTH > x and self.tower3ImgY + self.IMG_HALF_WIDTH > y):
                self.TYPE = self.BASE_TOWER_TYPE3
                self.drag = True
                print("Tower3")
            elif(self.tower4ImgX - self.IMG_HALF_WIDTH < x and self.tower4ImgY - self.IMG_HALF_WIDTH < y and self.tower4ImgX + self.IMG_HALF_WIDTH > x and self.tower4ImgY + self.IMG_HALF_WIDTH > y):
                self.TYPE = self.BASE_TOWER_TYPE4
                self.drag = True
                print("tower4")
            elif(self.tower5ImgX - self.IMG_HALF_WIDTH < x and self.tower5ImgY - self.IMG_HALF_WIDTH < y and self.tower5ImgX + self.IMG_HALF_WIDTH > x and self.tower5ImgY + self.IMG_HALF_WIDTH > y):
                self.drag = True
                self.TYPE = self.BASE_TOWER_TYPE5
                print("tower5")
        
        elif(eventtype == SDL_MOUSEBUTTONUP):
             for i in range(0,12):
                self.TILE.append([])
                for j in range(0,16):
                    if (self.TILE[i][j].GetXY('x') - self.IMG_HALF_WIDTH < x and self.TILE[i][j].GetXY('y') - self.IMG_HALF_WIDTH < 600 - y and self.TILE[i][j].GetXY('x') + self.IMG_HALF_WIDTH > x and self.TILE[i][j].GetXY('y') + self.IMG_HALF_WIDTH > 600 - y):
                        if(self.TYPE == self.BASE_TOWER_TYPE):
                            if(self.Playermoney >= Tower.Tower.price):
                               
                                    self.tower_list.append(Tower.Tower(self.TILE[i][j].GetXY('x'),self.TILE[i][j].GetXY('y')))
                                    self.TILE[i][j].state = False
                                    self.TILE[i][j].type = POINT.POINT.OBJECT_TYPE_1
                                    self.Playermoney-= Tower.Tower.price
                                    print("arr[%d][%d]" % (i,j))
                                    break
                        elif(self.TYPE == self.BASE_TOWER_TYPE2):
                            if(self.Playermoney >= Tower2.Tower2.price):
                                 self.tower_list.append(Tower2.Tower2(self.TILE[i][j].GetXY('x'),self.TILE[i][j].GetXY('y')))
                                 self.TILE[i][j].state = False
                                 self.TILE[i][j].type = POINT.POINT.OBJECT_TYPE_2
                                 self.Playermoney-= Tower2.Tower2.price
                                 print("arr[%d][%d]" % (i,j))
                                 break
             self.drag = False
             self.TYPE = None
             print("drag = False,TYPE = None")
        

        elif(eventtype == SDL_MOUSEMOTION and self.drag):
            pass
    def KeyboardFunc(self,key,type):
        if(type == SDL_KEYDOWN and key == SDLK_q):
            self.Playermoney+=10
        
    def draw(self):
        if(self.drag):
            for y in range(0,12):
                for x in range(0,16):
                    self.TILE[y][x].drawTemp()
        for i in range(0,len(self.tower_list)):
            self.tower_list[i].draw() ##<-------------------------------------문제
        for i in range(0,len(self.enemy)):
            self.enemy[i].draw()
        self.tower1Img.draw(self.tower1ImgX,600 - self.tower1ImgY)
        self.tower2Img.draw(self.tower2ImgX,600 - self.tower2ImgY)
        self.tower3Img.clip_draw(50,0,50,50,self.tower3ImgX,600 - self.tower3ImgY)
        self.tower4Img.clip_draw(50,0,50,50,self.tower4ImgX,600 - self.tower4ImgY)
        self.tower5Img.clip_draw(50,0,50,50,self.tower5ImgX,600 - self.tower5ImgY)
        self.settingImg.draw(self.settingImgX,600 - self.settingImgY)
        self.fast2xImg.draw(self.fast2xImgX,600 - self.fast2xImgY)
        self.startImg.draw(self.startImgX,600 - self.startImgY)
        self.puseImg.draw(self.puseImgX,600 - self.puseImgY)
        self.moneyImg.draw(self.moneyImgX,self.moneyImgY)
        self.lifeImg.draw(self.lifeImgX,600-self.lifeImgY)
        self.font.draw(self.moneyImgX,self.moneyImgY,"%d" % (self.Playermoney),(255,255,255))
        self.scoreFont.draw(self.scoreX,self.scoreY,"%d" % self.Playerscore,(255,255,255))
        self.scoreFont.draw(self.scoreX-50,self.scoreY-22,"Round:%d"%self.round,(255,255,255))
        self.font.draw(self.lifeImgX+30,600-self.lifeImgY,"%d"%(self.Playerlife),(255,0,0))
       # print("time = %d , watingTime:%d"%(self.time,self.watingTime))

    def updateAnermy(self):#########################################################################몬스터 생성
        if self.START == self.option :
                if self.enemyLV == 0:
                    self.enemy.append(enemyType1.enemyType1(self.TILE))
                    self.forCount+=1

                elif self.enemyLV == 1:
                    self.enemy.append(enermyType2.enermyType2(self.TILE))
                    self.forCount+=1

                elif self.enemyLV == 2:
                    pass

    def update(self):
        if self.option == self.START:
            for i in range(0,len(self.enemy)):
                self.enemy[i].update()
            for i in range(0,len(self.tower_list)):
                self.tower_list[i].update()
        GameManager.updateAnermy(self)