﻿from pico2d import *

class POINT:
    img = None
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.state = True #오브젝트가 존재하면 False
        if POINT.img == None:
            self.img = load_image("Texture\\Tile.png")
    def GetXY(self,XorYorState):
        if(XorYorState == 'x'):
            return self.x
        elif(XorYorState == 'y'):
            return self.y
        elif (XorYorState == 'state'):
            return self.state
    def drawTemp(self):
        self.img.draw(self.x,self.y)
        



