﻿from pico2d import *
import POINT
import Tower
import Tower2
import enemyType1
class GameManager:
    BASE_TOWER_TYPE,BASE_TOWER_TYPE2 = 1,2
    IMG_HALF_WIDTH = 25
    TYPE = None
    TILE = []
    TOWER_LIST = []
    tower1Img = None
    tower2Img = None
    fast2xImg = None
    puseImg = None
    startImg = None
    drag = None
    def __init__(self):
        self.tower1ImgX = 400
        self.tower1ImgY = 550
        
        self.tower2ImgX = 450
        self.tower2ImgY = 550

        self.fast2xImgX = 50
        self.fast2xImgY = 550
        
        self.puseImgX =  150
        self.puseImgY =  550

        self.startImgX = 100
        self.startImgY = 550
        self.drag = False

        self.enemy = enemyType1.enemyType1(self.TILE)

        for y in range(0,12):
            self.TILE.append([])
            for x in range(0,16):
                #self.TILE.append(POINT.POINT((x*(self.IMG_HALF_WIDTH*2))+(self.IMG_HALF_WIDTH),(y*(self.IMG_HALF_WIDTH*2))+(self.IMG_HALF_WIDTH)))
                self.TILE[y].append(POINT.POINT((x*(self.IMG_HALF_WIDTH*2))+(self.IMG_HALF_WIDTH),(y*(self.IMG_HALF_WIDTH*2))+(self.IMG_HALF_WIDTH)))
        if(GameManager.tower1Img == None):
            self.tower1Img = load_image("Texture\\BaseTowerImg.png")
        if(GameManager.tower2Img == None):
            self.tower2Img = load_image("Texture\\Base2TowerImg.png")
        if(GameManager.fast2xImg == None):
            self.fast2xImg = load_image("Texture\\Fast2XImg.png")
        if(GameManager.startImg == None):
            self.startImg = load_image("Texture\\StartImg.png")
        if(GameManager.puseImg == None):
            self.puseImg = load_image("Texture\\PuseImg.png")


    def mouseFunc(self,eventtype,x,y):
        if(eventtype == SDL_MOUSEBUTTONDOWN):#여기하면됨.
            if(self.fast2xImgX-self.IMG_HALF_WIDTH < x and self.fast2xImgY - self.IMG_HALF_WIDTH < y and self.fast2xImgX+self.IMG_HALF_WIDTH > x and self.fast2xImgY+ self.IMG_HALF_WIDTH > y):
                print("fast2xImgXtrue")
            elif(self.startImgX-self.IMG_HALF_WIDTH < x and self.startImgY - self.IMG_HALF_WIDTH < y and self.startImgX+self.IMG_HALF_WIDTH > x and self.startImgY+ self.IMG_HALF_WIDTH > y):
                print("true")

            elif(self.tower1ImgX-self.IMG_HALF_WIDTH < x and self.tower1ImgY - self.IMG_HALF_WIDTH < y and self.tower1ImgX+self.IMG_HALF_WIDTH > x and self.tower1ImgY+ self.IMG_HALF_WIDTH > y):
                self.drag = True
                self.TYPE = self.BASE_TOWER_TYPE
                print("startImgXtrue")
            elif(self.tower2ImgX-self.IMG_HALF_WIDTH < x and self.tower2ImgY - self.IMG_HALF_WIDTH < y and self.tower2ImgX+self.IMG_HALF_WIDTH > x and self.tower2ImgY+ self.IMG_HALF_WIDTH > y):
                self.drag = True
                self.TYPE = self.BASE_TOWER_TYPE2
                print('BASE_TOWER_TYPE2')

        elif(eventtype == SDL_MOUSEBUTTONUP):
             for i in range(0,12):
                self.TILE.append([])
                for j in range(0,16):
                    if (self.TILE[i][j].GetXY('x') - self.IMG_HALF_WIDTH<x and self.TILE[i][j].GetXY('y') - self.IMG_HALF_WIDTH<600-y and self.TILE[i][j].GetXY('x') + self.IMG_HALF_WIDTH > x and self.TILE[i][j].GetXY('y') + self.IMG_HALF_WIDTH > 600-y):
                        if(self.TYPE == self.BASE_TOWER_TYPE):
                            self.TOWER_LIST.append(Tower.Tower(self.TILE[i][j].GetXY('x'),self.TILE[i][j].GetXY('y')))
                            self.TILE[i][j].state = False
                            print("arr[%d][%d]"%(i,j))
                            break
                        elif(self.TYPE == self.BASE_TOWER_TYPE2):
                          self.TOWER_LIST.append(Tower2.Tower2(self.TILE[i][j].GetXY('x'),self.TILE[i][j].GetXY('y')))
                          break
             self.drag = False
             self.TYPE = None
             print("drag = False,TYPE = None")

        elif(eventtype == SDL_MOUSEMOTION and self.drag):
            pass
    def draw(self):
        if(self.drag):
            for y in range(0,12):
                #self.TILE.append([])
                for x in range(0,16):
                    self.TILE[y][x].drawTemp()
        for i in range(0,len(self.TOWER_LIST)):
            self.TOWER_LIST[i].draw() ##<-------------------------------------문제
        self.enemy.draw()
        self.tower1Img.draw(self.tower1ImgX,600-self.tower1ImgY)
        self.tower2Img.draw(self.tower2ImgX,600-self.tower2ImgY)
        self.fast2xImg.draw(self.fast2xImgX,600-self.fast2xImgY)
        self.startImg.draw(self.startImgX,600-self.startImgY)
        self.puseImg.draw(self.puseImgX,600-self.puseImgY)
       
    def update(self):
        self.enemy.update()