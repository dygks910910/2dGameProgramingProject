﻿import Tower
from pico2d import *

class Tower2(Tower.Tower):
    img = None
    
    def __init__(self,x,y):
        if(Tower2.img == None):
            self.img = load_image("Texture\\BaseTower2Temp.png")
        self.x = x
        self.y = y

    
    def draw(self):
        self.img.draw(self.x,self.y)


