﻿from pico2d import *
import POINT
import GameManager

class enemyType1:
    START_POINT_X = 25
    START_POINT_Y = 275
    Img = None
    LEFT,RIGHT,UP,DOWN = 1,2,3,4
    TILE_LIST = None
    def __init__(self,tile):
        if(enemyType1.TILE_LIST == None):
            self.TILE_LIST =tile
        if(enemyType1.Img == None):
            self.Img = load_image("Texture\\lv1Temp.png")
        self.speed = 1
        self.x = self.START_POINT_X
        self.y = self.START_POINT_Y
        self.state = self.RIGHT
        

    def left_move(self):
        self.x -= self.speed
    def right_move(self):
        self.x += self.speed
    def up_move(self):
        self.y += self.speed
    def down_move(self):
        self.y -= self.speed
    def changeState(self):
        for i in range(0,12):
            for j in range(0,16):
               if (self.TILE_LIST[i][j].GetXY('x')  == self.x and self.TILE_LIST[i][j].GetXY('y') ==self.y ):
                   if(self.state == self.RIGHT):
                       if(j < 14 and self.TILE_LIST[i][j+1].state == False):
                           self.state = self.UP
                       if(j < 14 and self.TILE_LIST[i][j+1].state == False and self.TILE_LIST[i+1][j] == False):
                           self.state = self.DOWN
                        ###---------------------------------------------------------------------------
                       if(j == 15 and i < 5):
                           self.state = self.UP
                       elif(j == 15 and i > 5):
                           self.state = self.DOWN
                   elif(self.state == self.UP):
                       if(i == 11 or(i < 11 and self.TILE_LIST[i+1][j].state == False )):
                           self.state = self.RIGHT
                   elif(self.state == self.DOWN):
                       if(i > 0 and self.TILE_LIST[i-1][j].state == False):
                           self.state = self.RIGHT
                   elif(self.state == self.LEFT):
                       if(j > 0 and self.TILE_LIST[i][j-1].state == False):
                           self.state = self.DOWN
                   if(j == 15 and i == 5):
                       self.state = self.RIGHT
                   #if( j < 15 and self.TILE_LIST[i][j+1].state == False):
                   #    if(i < 11 and i > 0 and self.TILE_LIST[i-1][j].state == False and self.TILE_LIST[i+1][j] == False):
                   #        self.state = self.LEFT
                   #    elif(i < 11 and self.TILE_LIST[i+1][j].state == False):
                   #        self.state = self.DOWN
                   #    elif(i > 0 and self.TILE_LIST[i-1][j].state == False):
                   #        self.state = self.UP
                   #    else:
                   #        self.state = self.UP
                   #elif(j < 15 and  self.TILE_LIST[i][j-1].state == False):
                   #    if(i < 11 and i > 0 and self.TILE_LIST[i-1][j].state == False and self.TILE_LIST[i+1][j] == False):
                   #        self.state = self.RIGHT
                   #    elif(i < 11 and self.TILE_LIST[i+1][j].state == False):
                   #        self.state = self.DOWN
                   #    elif(i > 0 and self.TILE_LIST[i-1][j].state == False):
                   #        self.state = self.UP
                   #    else:
                   #        self.state = self.DOWN
                   #elif(i < 11 and self.TILE_LIST[i+1][j] == False):
                   #    if(j < 15 and j > 0 and self.TILE_LIST[i][j+1].state == False and self.TILE_LIST[i][j-1].state== False):
                   #        self.state = self.DOWN
                   #    elif(j < 15 and self.TILE_LIST[i][j+1].state == False):
                   #        self.state = self.LEFT
                   #    elif(j > 0 and self.TILE_LIST[i][j-1].state == False):
                   #        self.state = self.RIGHT
                   #    else:
                   #        self.state = self.RIGHT
                   #elif(self.TILE_LIST[i-1][j]):
                   #    if(j < 15 and j > 0 and self.TILE_LIST[i][j+1].state == False and self.TILE_LIST[i][j-1].state== False):
                   #        self.state = self.UP
                   #    elif(j < 15 and self.TILE_LIST[i][j+1].state == False):
                   #        self.state = self.LEFT
                   #    elif(j > 0 and self.TILE_LIST[i][j-1].state == False):
                   #        self.state = self.RIGHT
                   #    else:
                   #        self.state = self.RIGHT
                   break
        #if(self.state == self.UP):
        #           print("state: up")
        #if(self.state == self.DOWN):
        #           print("state: down")
        #if(self.state == self.LEFT):
        #           print("state: left")
        #if(self.state == self.RIGHT):
        #           print("state: right")
                   


    handle_state ={
        LEFT:left_move,
        RIGHT:right_move,
        UP:up_move,
        DOWN:down_move
       }
         
    def update(self):
        self.changeState()
        self.handle_state[self.state](self)
    def draw(self):
        self.Img.draw(self.x,self.y)
    


