﻿import random
import json
import os

from pico2d import *
import GameManager
import game_framework
import main_state
import Tower


name = "MainStateLV1"

font = None
tower = None
background = None
gameManager = None
def enter():
    global background 
    global gameManager
    gameManager = GameManager.GameManager()
    background = load_image("Texture\\BackGround1.png")
    pass


def exit():
    pass


def pause():
    pass


def resume():
    pass


def handle_events():
    events = get_events()
    global gameManager
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(main_state)
        if event.type == SDL_MOUSEMOTION:
            gameManager.mouseFunc(event.type ,event.x,event.y)
            print("%d,%d"%(event.x,600-event.y))
        if(event.type == SDL_MOUSEBUTTONDOWN and event.button == SDL_BUTTON_LEFT):
            gameManager.mouseFunc(event.type ,event.x,event.y)
        if(event.type == SDL_MOUSEBUTTONUP and event.button == SDL_BUTTON_LEFT):
            gameManager.mouseFunc(event.type , event.x,event.y)


def update():
    gameManager.update()


def draw():
    global background
    clear_canvas()
    background.draw(400,300)
    gameManager.draw()
    update_canvas()




