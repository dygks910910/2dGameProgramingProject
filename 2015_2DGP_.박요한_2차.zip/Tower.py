﻿from pico2d import *

class Tower:
    img = None
    
    def __init__(self,x,y):
        if(Tower.img == None):
            self.img = load_image("Texture\\BaseTowerTemp.png")
        self.x = x
        self.y = y

    
    def draw(self):
        self.img.draw(self.x,self.y)
