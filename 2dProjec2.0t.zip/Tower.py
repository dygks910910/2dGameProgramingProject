﻿from pico2d import *
import math
import bullet
tower = None

class Tower:
    priceLV1 = 100
    index = []
    img = None
    FIRE,STOP = 1,2
    rangeImg = None
    bombImg = None
    explosionSound = None
    gatlling_gunSound = None


    def __init__(self,x,y):
        if(len(Tower.index) == 0):
            for i in range(0,20):
                self.index.append(18*i)
                print("%d"%(18*i))
        if Tower.gatlling_gunSound == None:
            self.gatlling_gunSound = load_music("Music\\sound_gattling_gun.ogg")
            self.gatlling_gunSound.set_volume(0)
        if Tower.explosionSound == None:
            self.explosionSound = load_music("Music\\sound_explosion.ogg")
            self.explosionSound.set_volume(0)
        if(Tower.img == None):
            self.img = load_image("Texture\\BaseTowerSprite.png")
        if(Tower.rangeImg == None):
            self.rangeImg = load_image("Texture\\target_circle_range150.png")
        if Tower.bombImg == None:
            self.bombImg= load_image("Texture\\bomb.png")



        gatlling_gun_Sound = False
        explosion_Sound = False

        self.bullet = bullet.bullet(x,y)
        self.x = x
        self.y = y
        self.frame = 0  #총19개 이미지
        self.imgX = 0
        self.imgY = 50
        self.range = 150 #반경50
        self.click = False
        self.option = self.STOP
        self.att = 50
        self.fireSpeed = 2
        self.towerLv = 1


    def update(self,enermy):
        if(self.culcuratingRange(enermy.x,enermy.y)):
            frame = self.calcuratorToDegree(enermy.x,enermy.y)
            self.frame = frame
        if(self.option == self.FIRE):
            if self.bullet.deleteState == True:
                del(self.bullet)
                self.bullet = bullet.bullet(self.x,self.y)
            self.bullet.update(enermy)
        pass

        
        pass
    def draw(self):
        if self.option == self.FIRE:
             self.img.clip_draw((self.imgX+50)*self.frame,self.imgY-50,50,50,self.x,self.y)
             self.bullet.draw()
        else:
            self.img.clip_draw((self.imgX+50)*self.frame,self.imgY,50,50,self.x,self.y)
        if(self.click == True):
            self.rangeImg.draw(self.x,self.y)


    def culcuratingRange(self,monsterX,monsterY):
        if(self.x >= monsterX):
           if(math.sqrt(((self.x-monsterX)*(self.x-monsterX)+((self.y - monsterY)*(self.y-monsterY)))) <= self.range):
               self.option = self.FIRE
               return True
           else:
               self.option = self.STOP
               return False
        elif(self.x <= monsterX):
            if(math.sqrt((monsterX-self.x)*(monsterX-self.x)+(monsterY-self.y)*(monsterY-self.y)) <= self.range):
                self.option = self.FIRE
                return True
            else:
                self.option = self.STOP
                return False


  

    def calcuratorToDegree(self,monsterX,monsterY):
         print("거리:%d"%(math.sqrt(((self.x-monsterX)*(self.x-monsterX)+((self.y - monsterY)*(self.y-monsterY))))))
         x = monsterX- self.x
         y= monsterY-self.y
         temp = math.atan2(y,x)#y/x 계산해줌
         
         degree = temp*(180/3.14159265)
         if(degree < 0):
            degree = 359+degree
            print("%d"%(degree))
         for i in range(0,20):
              if i == 19:
                    if(self.index[19] <= degree and degree >= self.index[0]):
                         return 19
              elif(self.index[i] <= degree and degree <= self.index[i+1]):
                    return i
         else:
            return 0


enermy = None
TILE = []
import enemyType1
def testing_debug():
    global TILE;
    for y in range(0,12):
            self.TILE.append([])
            for x in range(0,16):
                #self.TILE.append(POINT.POINT((x*(self.IMG_HALF_WIDTH*2))+(self.IMG_HALF_WIDTH),(y*(self.IMG_HALF_WIDTH*2))+(self.IMG_HALF_WIDTH)))
                self.TILE[y].append(POINT.POINT((x * (self.IMG_HALF_WIDTH * 2)) + (self.IMG_HALF_WIDTH),(y * (self.IMG_HALF_WIDTH * 2)) + (self.IMG_HALF_WIDTH)))
    enermy = enemyType1.enemyType1(TILE)
    open_canvas()
    global tower
    tower = Tower(400,300)
    while(True):
       clear_canvas()
       handle_events()
       tower.draw()
       update_canvas()


def handle_events():
    events = get_events()
    global enermy
    global tower
    for event in events:
        if event.type == SDL_MOUSEMOTION:
            tower.update(event.x,600-event.y)
if __name__ == "__main__":
    testing_debug()