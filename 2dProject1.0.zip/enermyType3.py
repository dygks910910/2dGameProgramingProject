﻿import enemyType1
from pico2d import *


class enermyType3(enemyType1.enemyType1):

    """description of class"""


