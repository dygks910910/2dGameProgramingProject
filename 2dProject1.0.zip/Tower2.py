﻿import Tower
from pico2d import *

class Tower2(Tower.Tower):
    img = None
    def __init__(self,x,y):
        if(len(Tower2.index) == 0):
            for i in range(0,20):
                self.index.append(18*i)
                print("%d"%(18*i))
        if(Tower2.img == None):
            self.img = load_image("Texture\\Tower2Sprite.png")
        self.frame= 0
        self.option = self.STOP
        self.x = x  
        self.y = y
        self.frame = 0  #총19개 이미지
        self.imgX = 0
        self.imgY = 50

        self.towerPrice = 150
    def draw(self):
        if self.option == self.FIRE:
            self.img.clip_draw((self.imgX+50)*self.frame,self.imgY-50,50,50,self.x,self.y)
        else:
            self.img.clip_draw((self.imgX+50)*self.frame,self.imgY,50,50,self.x,self.y)
    

