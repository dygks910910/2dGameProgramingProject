﻿import enemyType1
from pico2d import *


class enermyType3(enemyType1.enemyType1):
    Img = None
    def __init__(self,tile):
        if self.Img == None:
            self.Img = load_image("Texture\\enermyLV3.png")
        if self.TILE_LIST == None:
            self.TILE_LIST = tile
        if(enermyType3.hp_gage_img == None):
            self.hp_gage_img = load_image("Texture\\hp_gage_img.png")
        self.frame= 0
        self.speed = 0.5
        self.hp = 100
        self.x = self.START_POINT_X
        self.y = self.START_POINT_Y
        self.state = self.RIGHT
        self.delSwitch = False
        self.money = 600

    def update(self):
        self.frame = (self.frame+1) %8
        self.changeState()
        self.handle_state[self.state](self)
        if(self.hp <= 0):
            self.delSwitch = True
    def draw(self):
        self.Img.clip_draw(50*self.frame,0,50,50,self.x,self.y)
        self.hp_gage_img.clip_draw(0,0,int(self.hp/2),5,self.x,self.y+25)
    """description of class"""


