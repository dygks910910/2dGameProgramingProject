from pico2d import *
bulet = None

class bullet:
    bulletImg = None
    bulletbombImg = None

    gatlling_gunSound = None
    def __init__(self,towerx,towery):
       
        if bullet.bulletImg == None:
            self.bulletImg = load_image("Texture\\LongRangeBullet.png")
        if(bullet.bulletbombImg == None):
            self.bulletbombImg = load_image("Texture\\bomb.png")
        self.frame = 0
        self.startx = towerx
        self.starty = towery
        self.bulletX = towerx
        self.bulletY = towery
        self.deleteState = False
        self.rad = 0
        self.bomb = False
        self.speed =10
    def draw(self):
        if self.bomb == False:
            self.bulletImg.rotate_draw(self.rad,self.bulletX,self.bulletY)
        elif self.bomb == True:
            self.bulletbombImg.clip_draw(self.frame*50,0,50,50,self.bulletX,self.bulletY)
    
    def update(self,destX,destY):
        if self.bomb == False:
            x = destX - self.startx
            y = destY - self.starty
            self.rad = math.atan2(y,x)
            degree = self.rad * (180/3.141592)

            self.bulletX += self.speed * math.cos(self.rad)
            self.bulletY += self.speed * math.sin(self.rad)
            if(destX-25  <= self.bulletX  and self.bulletX<=destY+25 and destY-25<= self.bulletY and self.bulletY <= destY+25):
                self.bomb = True
        #    print("X:%d , Y:%d"%(self.bulletX,self.bulletY))
        elif(self.bomb):
                self.frame +=1
                if self.frame == 3:
                     self.deleteState = True




def testing_debug():
    global bulet
    index = []
    for i in range(0,20):
          index.append(18*i)
          print("%d"%(18*i))
    open_canvas()
    bulet = bullet(400,300)
    while(True):
        clear_canvas()
        bulet.draw()
        bulet.update(500,500)

        handle_events()
        update_canvas()




def handle_events():
    events = get_events()

    global bulet
    for event in events:
        if event.type == SDL_MOUSEMOTION:

            pass


if __name__ == "__main__":
    testing_debug()
