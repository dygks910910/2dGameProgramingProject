import bullet
from pico2d import *
bulet = None
class bullet_Missail(bullet.bullet):
    bulletbombImg = None
    missail_bulletImg = None
    def __init__(self,towerx,towery):
        if bullet_Missail.missail_bulletImg == None:
            self.missail_bulletImg = load_image("Texture\\missailBullet.png")
        if(bullet_Missail.bulletbombImg == None):
            self.bulletbombImg = load_image("Texture\\bomb.png")
        self.frame = 0
        self.startx = towerx
        self.starty = towery
        self.bulletX = towerx
        self.bulletY = towery
        self.deleteState = False
        self.rad = 0
        self.bomb = False
        self.speed =10

    def draw(self):
            if self.bomb == False:
               self.missail_bulletImg.rotate_draw(self.rad,self.bulletX,self.bulletY)
            elif self.bomb == True:
               self.bulletbombImg.clip_draw(self.frame*50,0,50,50,self.bulletX,self.bulletY)

def testing_debug():
    global bulet
    index = []
    for i in range(0,20):
          index.append(18*i)
          print("%d"%(18*i))
    open_canvas()
    bulet = bullet_Missail(400,300)
    while(True):
        clear_canvas()
        bulet.draw()
        bulet.update(0,0)

        handle_events()
        update_canvas()




def handle_events():
    events = get_events()

    global bulet
    for event in events:
        if event.type == SDL_MOUSEMOTION:

            pass


if __name__ == "__main__":
    testing_debug()
